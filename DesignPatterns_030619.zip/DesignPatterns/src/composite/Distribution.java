package composite;

public interface Distribution {
	public void sendMessage(String msg);
}
