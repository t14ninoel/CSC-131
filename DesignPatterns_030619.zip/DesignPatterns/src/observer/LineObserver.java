package observer;

public interface LineObserver {

	public void handleLine(LineSubject source);
}
