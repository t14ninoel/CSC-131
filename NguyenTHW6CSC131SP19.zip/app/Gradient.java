package app;
import grading.*; 
import java.util.*;

public class Gradient {

	public static void main(String[] args) {
		
		Filter                   paFilter;      
	    Grade                    courseGrade, hwGrade, paGrade;
	    GradingStrategy          courseStrategy, hwStrategy, paStrategy;
	    List<Grade>              grades, hws, pas;
	    Map<String, Double>      courseWeights;

	    if ((args == null) || (args.length != 13))
	       {
	           System.err.println("You must enter all 13 grades. (Use NA for missing.)");
	           System.exit(1);
	       }
	    
	    paFilter   = new DropFilter(true, false);
	    paStrategy = new TotalStrategy();
	       
	    hwStrategy = new TotalStrategy();
	    
	    courseWeights = new HashMap<String, Double>();
	    courseWeights.put("PAs",     0.4);
	    courseWeights.put("HWs",     0.1);
	    courseWeights.put("Midterm", 0.2);
	    courseWeights.put("Final",   0.3);
	    courseStrategy = new WeightedTotalStrategy(courseWeights);

	
	    try
	       {
	    	pas = new ArrayList<Grade>();
	           for (int i=0; i<6; i++)
	           {
	               pas.add(parseGrade("PA"+(i+1), args[i]));
	           }
	           
	           paGrade = paStrategy.calculate("PAs", paFilter.apply(pas));
	           
	           hws = new ArrayList<Grade>();
	           for (int i=0; i<5; i++)
	           {
	               hws.add(parseGrade("HW"+(i+1), args[i+6]));
	           }
	           
	           hwGrade = hwStrategy.calculate("HWs", hws);
	           
	           grades = new ArrayList<Grade>();
	           grades.add(paGrade);
	           grades.add(hwGrade);
	           grades.add(parseGrade("Midterm", args[11]));
	           grades.add(parseGrade("Final",   args[12]));
	           
	           courseGrade = courseStrategy.calculate("Course Grade", grades);
	           
	           System.out.println(courseGrade.toString());   
	       }
	    catch (SizeException se)
	       {
	           System.out.println("You entered too few valid grades.");
	       }
	       catch (IllegalArgumentException iae)
	       {
	       
	       }
	    
	}
	
	private static Grade parseGrade(String key, String value) throws IllegalArgumentException
	   {
	       Grade result;
	      
	       try
	       {
	           Double v;
	           if (value == null) v = null;
	           else v = new Double(Double.parseDouble(value));
	          
	           result = new Grade(key, v);
	       }
	       catch (NumberFormatException nfe)
	       {
	           result = new Grade(key, null);
	       }
	      
	       return result;
	   }
}
