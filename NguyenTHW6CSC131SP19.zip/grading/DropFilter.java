package grading;
import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

public class DropFilter implements Filter {
	private boolean shouldDropLowest;
	private boolean shouldDropHighest;
	private int toBeDropped = 0; 

	
	public DropFilter() {
		this.shouldDropHighest = true;
		this.shouldDropLowest = true;
		this.toBeDropped = 2;
	}
	
	public DropFilter(boolean shouldDropLowest, boolean shouldDropHighest)
	{
		this.shouldDropLowest = shouldDropLowest;
		this.shouldDropHighest = shouldDropHighest;
		
		if (shouldDropLowest && !shouldDropHighest)
		{
			toBeDropped = 1;
		}
		else if (!shouldDropLowest && shouldDropHighest)
		{
			toBeDropped = 1;
		}
		else if (shouldDropLowest && shouldDropHighest)
		{
			toBeDropped = 2;
		}
		else {
			toBeDropped = 0;
		}
	}
	
	@Override
	public List<Grade> apply(List<Grade> grades) throws SizeException {
		 if (grades == null) {
	           throw new SizeException("Lists cannot be null.");
	       } else if (grades.size() < this.toBeDropped) {
	           throw new SizeException("Lists cannot be less than number to be dropped.");
	       } else if (grades.size() == this.toBeDropped) {
	           throw new SizeException("Lists cannot be equal to number to be dropped.");
	       } else {
	    	   List<Grade> filteredGrades = new ArrayList<Grade>();
	    	   
	    	   List<Grade> sortedGrades = grades;
	           Collections.sort(sortedGrades);
	           
	           for (int i = 0; i < sortedGrades.size(); i++) {
	               if (shouldDropHighest && shouldDropLowest) {
	                   //skip the highest grade and lowest grade, "drop" them
	                   if (i != 0 && i != sortedGrades.size() - 1) {
	                       filteredGrades.add(sortedGrades.get(i));
	                   }
	               } else if (shouldDropHighest) {
	                   //skip the highest grade, "drop" it
	                   if (i != sortedGrades.size() - 1) {
	                       filteredGrades.add(sortedGrades.get(i));
	                   }
	               } else if (shouldDropLowest) {
	                   //skip the lowest grade, "drop" it
	                   if (i != 0) {
	                       filteredGrades.add(sortedGrades.get(i));
	                   }
	               } else {
	                   //copy everything over
	                   filteredGrades.add(sortedGrades.get(i));
	               }
	           }
	           
	           return filteredGrades;
	       }
	}

}	
