package grading;

public class Grade implements Comparable<Grade>{

	private String key;
	private Double value;
	
	@Override
	public int compareTo(Grade other)
	{
		if (this.value == null && other.value != null)
		{
			return -1;
		}
		else if (this.value == null && other.value == null)
		{
			return 0;
		}
		else if (this.value !=null && other.value == null)
		{
			return 1;
		}
		else {
			return this.value.compareTo(other.value);
		}
	}
	
	public Grade(String key) throws IllegalArgumentException
	{
		if (key == null || key == "")
		{
			throw new IllegalArgumentException("Key cannot be null or empty");
		}
		this.key = key;
		this.value = 0.0;
	}
	
	public Grade(String key, Double value) throws IllegalArgumentException
	{
		if (key == null || key == "")
		{
			throw new IllegalArgumentException("Key cannot be null or empty");
		}
		this.key = key;
		this.value = value;
	}
	
	public String getKey()
	{
		return this.key;
	}
	
	public Double getValue()
	{
		return this.value;
	}
	
	public String toString()
	{
		if (value != null)
		{
			return String.format("%s: %5s", key, this.value);
		}
		else {
			return String.format("%s: %5.1f", key, "NA");
		}
	}
}
