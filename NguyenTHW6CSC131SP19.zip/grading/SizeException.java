package grading;

public class SizeException extends Exception {

	public static final long serialVersionUID = 1L;
	
	public SizeException()
	{
		
	}
	
	public SizeException(String message) {
		super(message);
	}

}
