package grading;
import java.util.List;

public class TotalStrategy implements GradingStrategy {

	public TotalStrategy() {}
	
	public Grade calculate (String key, List<Grade> grades) throws SizeException
	{
		if (grades == null)
		{
			throw new SizeException("Lists cannot be null");
		}
		else if (grades.isEmpty())
		{
			throw new SizeException("Lists cannot be empty");
		}
		else {
			double runningTotal = 0.0;
			
			for (Grade grade : grades)
			{
				runningTotal += grade.getValue();
			}
			
			return new Grade(key, runningTotal);
}
	}
}
