package grading;
import java.util.Map;
import java.util.List;
import grading.SizeException;


public class WeightedTotalStrategy implements GradingStrategy {

	public Map<String, Double> weights;
	
	public Grade calculate (String key, List<Grade> grades) throws SizeException
	{
		if (grades == null)
		{
			throw new SizeException("Lists cannot be null");
		}
		else if (grades.isEmpty())
		{
			throw new SizeException("Lists cannot be empty");
		}
		else {
			double runningTotal = 0;
			
			for (Grade grade : grades)
			{
				double weight = 1.0;
			
			
			if (weights != null && weights.get(grade.getKey()) != null)
			{
				weight = weights.get(grade.getKey());
			}
			
			if (weight < 0.0)
			{
				weight = 0.0;
			}
			
			double gradeValue = Missing.doubleValue(grade.getValue());
			
			runningTotal += (gradeValue * weight);
		}
		
		return new Grade(key, runningTotal);
	}
	}
	
	public WeightedTotalStrategy()
	{
		this.weights = null;
	}
	
	public WeightedTotalStrategy(Map<String, Double> weights)
	{
		this.weights = weights;
	}
}
